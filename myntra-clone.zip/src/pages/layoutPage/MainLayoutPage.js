import MainLayout from "../../components/Home/MainLayout";

const MainLayoutPage = () => {
  return (
    <>
      <MainLayout />
    </>
  );
};

export default MainLayoutPage;
