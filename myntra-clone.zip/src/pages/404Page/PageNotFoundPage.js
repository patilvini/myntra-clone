import PagenotFound from "../../components/pagenotfound/PagenotFound";

const PageNotFoundPage = () => {
  return (
    <>
      <PagenotFound />
    </>
  );
};

export default PageNotFoundPage;
