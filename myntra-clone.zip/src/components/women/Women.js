import AccordionFilters from "../filters/AccordionFilters";

const Women = () => {
  return (
    <>
      <AccordionFilters />
      <p>Women</p>
    </>
  );
};

export default Women;
