import AccordionFilters from "../filters/AccordionFilters";

const Men = () => {
  return (
    <>
      <AccordionFilters />
      <p>Men</p>
    </>
  );
};

export default Men;
