const Button = (props) => {
  return <button>{props.title}</button>;
};

export default Button;
