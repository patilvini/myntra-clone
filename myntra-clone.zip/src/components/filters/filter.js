const Filter = () => {
  return <h1>Radio</h1>;
};

export default Filter;
