const AccordionFilters = () => {
  return <div>AccordionFilters</div>;
};

export default AccordionFilters;
