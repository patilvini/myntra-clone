const Home = () => {
  return (
    <div>
      <h1 className="mt-80">This is Home Page</h1>
    </div>
  );
};

export default Home;
