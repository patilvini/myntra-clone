const Breadcrumb = () => {
  return <h4>Breadcrumb</h4>;
};

export default Breadcrumb;
