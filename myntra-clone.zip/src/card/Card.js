const Card = () => {
  return (
    <div>
      <img />
      <div>
        <h2>Brand</h2>
        <p>name</p>
        <h4>Price</h4>
      </div>
    </div>
  );
};

export default Card;
